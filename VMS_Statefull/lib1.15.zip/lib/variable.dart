//main.dart
String subheadertxt = "PLEASE SELECT ONE OF THE FOLLOWING OPTION";
String subheadername = "PLEASE SELECT YOUR NAME";
String subheaderoption = "PLEASE SELECT ONE OPTION";
String subheadernone = "";
double width50 = 50;
double width40 = 40;
double widthfactorlong = 0.7;
double widthfactorshort = 0.33;

// time.dart
dynamic time;
dynamic times;
dynamic timeGreet;
bool? isDay;
