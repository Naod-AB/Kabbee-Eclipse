// ignore_for_file: prefer__ructors, avoid_print, prefer_const_constructors

//import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:visitor_management/index.dart';
// import 'package:visitor_management/selection.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}
